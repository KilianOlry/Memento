-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Hôte : 127.0.0.1:3306
-- Généré le : sam. 25 nov. 2023 à 16:11
-- Version du serveur : 8.0.31
-- Version de PHP : 8.2.0

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `memento`
--

-- --------------------------------------------------------

--
-- Structure de la table `post_it`
--

DROP TABLE IF EXISTS `post_it`;
CREATE TABLE IF NOT EXISTS `post_it` (
  `id` int NOT NULL AUTO_INCREMENT,
  `title` varchar(50) NOT NULL,
  `content` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `user_id` int DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `memento_user_id` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `post_it`
--

INSERT INTO `post_it` (`id`, `title`, `content`, `date`, `user_id`, `created_at`) VALUES
(6, 'Bonjour', 'hhtyhtyhty\r\nhthththt\r\nhtyhthtyhth\r\nhyththttyhtty', '2023-11-21', NULL, '2023-11-21 08:54:56'),
(7, 'yoyoy', 'yoy\r\nyiyopk\r\nyopkkyy', '2023-11-21', NULL, '2023-11-21 11:09:47'),
(8, 'Benoit', 'yo', '2023-11-22', NULL, '2023-11-21 13:12:15'),
(9, 'Benoit', 'hgththh', '2023-11-21', NULL, '2023-11-21 13:22:06'),
(10, 'jgtrgjgr', 'gkrtig,gtrg', '2023-11-22', NULL, '2023-11-21 13:24:05'),
(14, 'Liste de course', 'Fromage\r\nVin\r\nchocolat', '2023-11-22', 1, '2023-11-21 15:05:44'),
(15, 'Liste de course', 'Chocolat\r\nFromage\r\nJambon', '2023-11-21', 4, '2023-11-21 15:33:54'),
(16, 'Taches 3', 'huy\r\ngtrgr\r\ngrtgr\r\ngtrgrg\r\ngtrgrg', '2023-11-21', 1, '2023-11-21 15:38:27'),
(19, 'Test 4', 'David Halliday\r\nSoprano\r\nEminem\r\nSpider-man', '2023-11-22', NULL, '2023-11-25 15:24:06'),
(20, 'Test 4', 'SpiderMan 2\r\nCyberpunk PhantomLiberty\r\nUFC 5\r\nAssassin\'s Creed ', '2023-11-23', 1, '2023-11-25 15:25:34');

-- --------------------------------------------------------

--
-- Structure de la table `user`
--

DROP TABLE IF EXISTS `user`;
CREATE TABLE IF NOT EXISTS `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;

--
-- Déchargement des données de la table `user`
--

INSERT INTO `user` (`id`, `name`, `email`, `password`) VALUES
(1, 'kilian', 'user@user.com', '$2y$10$UiJJe7l4Mi663NATObKO0.u8UGP7HMozuGrpRBXKMeWFMuBQAhfUi'),
(2, 'Mary Tran', 'nuxuqipap@mailinator.com', '$2y$10$4p//fVanqItObCcc6NWlOOEnA7TcEOAkoKD4F4Lx.YlC/RMvQhzlG'),
(3, 'Veyrone', 'veyrone.bugatti@gmail.com', '$2y$10$RxseK9yCxrAP9dqqmob0C.3Rkq.XUo0scuhSz5XbGa0OVMtWoF4IK'),
(4, 'benoit', 'benoit.user@gmail.com', '$2y$10$uYBnxcaGnvaJ/uZ18kQImO7d6m2eu5Kn1MRL6.uSZu89AWpqjvAG.'),
(5, 'Maxence', 'maxence@gmail.com', '$2y$10$rativ/zyHL5Qzfo6YiHjMOCx/dCY1Wllws/edvuGZlVexKuWRZzG2'),
(6, 'kik', 'olry.kilian@gmail.com', '$2y$10$yv473u8Wk7pK5YGmS8a4tu6mXNX8/Us9gYKHB69oaZJYHWVXK9JIC'),
(7, 'Roanna Edwards', 'celaw@mailinator.com', '$2y$10$UTSNvrvBr1RbOcmklOQXS.SQeU6ZXtF1dkDgv.rF836vzxbmCu.8O'),
(8, 'kilian', 'user@user.com', '$2y$10$ChmChKEI1mYWhBWSAlKwQOMcnTEugQD3ErCw.sxw/2esX3lfrzExW'),
(9, 'Test', 'test.test@gmail.com', '$2y$10$nhvLU60S.CpagW/rf24Kiuoug6sJQiFPT5gtsYhxuoMOcPRxbJ7XW');

--
-- Contraintes pour les tables déchargées
--

--
-- Contraintes pour la table `post_it`
--
ALTER TABLE `post_it`
  ADD CONSTRAINT `user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
